//entry point for kernel

void kernel_main()
{
	// your kernel code goes here
	kernel_print("HELLO , KERNEL!");

}
