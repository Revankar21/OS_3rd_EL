#ifndef KERNEL_UTILS_H
#define KERNEL_UTILS_H

void kernel_print(const char* message)


#endif
