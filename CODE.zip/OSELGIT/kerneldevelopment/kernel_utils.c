#include "kernel_utils.h"

void kernel_print(const char* message){
	//code to print msg on scrn
}
